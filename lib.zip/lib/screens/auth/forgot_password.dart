import 'package:Obecno/core/constants/app_sizes.dart';
import 'package:Obecno/core/constants/text_styles.dart';
import 'package:Obecno/core/state/change_notifier_provider.dart';
import 'package:Obecno/features/auth/providers/auth_provider.dart';
import 'package:Obecno/screens/auth/login_pass.dart';
import 'package:Obecno/screens/auth/otp.dart';
import 'package:Obecno/widgets/back_button.dart';
import 'package:flutter/material.dart';
import '../../core/constants/all_colors.dart';
import '../../widgets/custom_textfield.dart';
import '../../widgets/my_button.dart';
import '../../widgets/text_widget.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final TextEditingController _emailController = TextEditingController(
    text: "suleman@naxovatetechnologies.com",
  );
  bool _isEdited = false;
  final FocusNode _emailFocus = FocusNode();

  String? _errorText;

  @override
  void initState() {
    super.initState();

    /// ✅ AUTO OPEN KEYBOARD
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _emailFocus.requestFocus();
    });
  }

  bool _validate() {
    String email = _emailController.text.trim();

    if (email.isEmpty) {
      setState(() => _errorText = "Email is required");
      return false;
    }

    final emailRegex = RegExp(r"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$");

    if (!emailRegex.hasMatch(email)) {
      setState(() => _errorText = "Enter valid email");
      return false;
    }

    setState(() => _errorText = null);
    return true;
  }

  @override
  void dispose() {
    _emailController.dispose();
    _emailFocus.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor: kWhite,

      body: Padding(
        padding: AppSizes.DEFAULT,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 10),

            /// BACK BUTTON
            Padding(
              padding: const EdgeInsets.only(top: 40),
              child: Align(
                alignment: Alignment.centerLeft,
                child: BackButtonBg(),
              ),
            ),

            const SizedBox(height: 60),

            /// TITLE
            Center(child: AppText.h4("Forgot Password")),

            const SizedBox(height: 40),

            /// EMAIL FIELD
            CustomTextField(
              controller: _emailController,
              focusNode: _emailFocus,
              labelText: "Email",
              hintText: "Enter your email",
              haveLebelText: true,
              radius: 14,
              errorBorderColor: _errorText == null ? kBorderColor : Colors.red,
              focusedBorderColor: _errorText == null
                  ? kPrimaryColor
                  : Colors.red,
              backgroundColor: kWhite,
              txtColor: kBlack,
              onChanged: (_) {
                if (_errorText != null) {
                  setState(() => _errorText = null);
                }
              },
            ),

            if (_errorText != null)
              Padding(
                padding: const EdgeInsets.only(top: 6, left: 4),
                child: TextWidget(
                  text: _errorText!,
                  size: 12,
                  color: Colors.red,
                ),
              ),

            /// ✅ THIS IS THE KEY
            const Spacer(),

            /// BUTTON (NATURAL POSITION)
            SafeArea(
              top: false,
              child: MyButton(
                mTop: 8,
                mBottom: 16,
                buttonText: "Reset Password",
                backgroundColor: kBlack,
                fontColor: kWhite,
                onTap: () async {
                  if (!_validate()) return;
                  final ok = await context.read<AuthProvider>().forgotPassword(
                    _emailController.text.trim(),
                  );
                  if (!ok || !context.mounted) return;
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(builder: (_) => const OTPScreen()),
                    (route) => true,
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
